import os

def input_card_info():
	f = open('card.txt',"a+")
	name = input("name:") 
	phone = input("phone:")
	qq = input("qq:")
	f.write(name+"\n")
	f.write(phone+"\n")
	f.write(qq+"\n")
	f.close()

def new_card():
	newInfo = input("input new card in details:")
	input_card_info()
	print("添加名片成功")

def show_all():
	if os.path.exists('card.txt'):
		f = open("card.txt")
		j = 0
		lines = f.readlines()
		for line in lines:
			print(line)
			if j == 2:
				print("------------")
				j = -1
			j = j + 1
		f.close()
		print("已输出所有名片信息")
	else:
		print("这儿没有任何名片信息")

def search_card(name):
	flag = 0
	r = open("card.txt","r")
	lines = r.readlines()
	for line in lines:
		# print(line)
		if line[0:-1] == name:
			flag = 1
			print("-----------------------")
			print("we find it")
			print("-----------------------")
			tmp = input("do you want to modify the info?(yes or no)")
			if tmp == "yes":
				r.close()
				tmp = deal_card(name)
				if tmp == 0:
					return 0
			if tmp == "no":
				return 0
	if flag == 0:
		print("-----------------------")
		print("there's no such a name!")
		print("-----------------------")

def deal_card(name):
	print("----------------")
	print("0 返回")
	print("1 修改")
	print("2 删除")
	print("----------------")
	num = int(input("input the number of function to choose:"))
	print("------------------------------------------------")
	if num == 1:
		tp = 0
		# print("修改开始")
		r = open("card.txt","r")
		lines = r.readlines()
		w = open("card.txt","w")
		for line in lines:
			if 0 < tp < 3:
				tp = tp + 1
				continue
			if line[0:-1] == name:
				tp = tp + 1
				continue
			w.write(line)
		w.close()
		r.close()
		# print("修改结束")
		input_card_info()
		print("----------")
		print("修改成功")
		print("----------")			
		return 0
	elif num == 2:
		tp = 0
		r = open("card.txt","r")
		lines = r.readlines()
		w = open("card.txt","w")
		for line in lines:
			if 0 < tp < 3:
				tp = tp + 1
				continue
			if line[0:-1] == name:
				tp = tp + 1
				continue
			w.write(line)
		w.close()
		r.close()
		print("----------")
		print("删除成功")
		print("----------")
		return 0
	elif num == 0:
		return 0
