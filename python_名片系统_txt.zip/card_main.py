# -*- coding: utf-8 -*-
import card_tool_;

def show_menu():
	print("----------------")
	print("0 退出")
	print("1 新建名片")
	print("2 显示全部名片")
	print("3 查询名片")
	print("----------------")

def getUserChoose():
	print("------------------------------------------------")
	return int(input("input the number of function to choose:"))
	print("------------------------------------------------")

def doFunction(n):
	if n == 0:
		return -1
	elif n == 1:
		card_tool_.new_card()
	elif n == 2:
		card_tool_.show_all()
	elif n == 3:
		print("------------------------------------------------")
		name = input("input the name what you want to search:")
		print("------------------------------------------------")
		card_tool_.search_card(name)

def main():
	while 1:
		show_menu()
		ans = doFunction(getUserChoose())
		if ans == -1:
			print("------------------------------------------------")
			print("goodbye")
			print("------------------------------------------------")
			break

if __name__ == "__main__":
	main()
