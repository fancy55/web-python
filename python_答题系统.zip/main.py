# -*- coding: utf-8 -*-
import json

def getItem(num,v,score):   #根据题目类型来判断
	for i in range(len(v) - num):
		print(v[i])
	res = input("你的选择是：")
	if res == v[len(v) - num] or (num == 2 and res == v[len(v) - num + 1]):
		print("-----right")
		score = score + 1
	else:
		print("-----error")
		print("-----这道题的正确答案是：",v[len(v) - num])
	print("----------------------------------------")
	return score

def printItem(it):         #输出题库
	print("题库：")
	for k,v in it.items():
		print(k, v[0])
	showMenu(it)

def begin(it):             #开始答题
	flag = 1 # 玩家的选择权
	score = 0
	while flag == 1:
		print("----------------------------------------")
		print("本次共有",len(it),"道题")
		ans = input("现在即将开始答题\n规则如下：每答对一题即可获得一分\nare you ready?(yes or no)")
		print("----------------------------------------")
		if ans == "yes":
			for k,v in it.items():
				print(k,end = "")
				if v[len(v) - 2].lower() == v[len(v) - 1] and v[len(v) - 2] != v[len(v) - 1] :
					score = getItem(2,v,score)
				else:
					score = getItem(1,v,score)
			print("作答结束\n你的分数是：%d分\n你的正确率为：%.2f%%"%(score,score/len(it)*100))
			flag = 0
		else :
			tmp = input("您是否要退出(yes or no)")
			if tmp == "yes" :
				print("已退出")
				showMenu(it)
			else: flag = 1


def showMenu(it):         #功能
	print("----------------------------------------")
	print("功能:1、查看题库，2、进入答题")
	choose = int(input("请选择："))
	print("----------------------------------------")
	if choose == 1:
		printItem(it)
	elif choose == 2:
		begin(it)

def main():
	f = open("word.json","r")
	it = json.load(f)
	showMenu(it)
	

if __name__ == "__main__":
	main()