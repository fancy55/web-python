def input_card_info():
	l = []
	name = input("name:") 
	phone = input("phone:")
	qq = input("qq:")
	l.append(name)
	l.append(phone)
	l.append(qq)
	return l

def new_card():
	newInfo = input("input new card in details:")
	l = []
	l = input_card_info()
	print("添加名片成功")
	return l

def show_all(card):
	if len(card) == 0:
		print("这儿没有任何名片信息")
	else:
		for i in card:
			for j in i:
				print(j, end = ' ')
			print("")
		print("已输出所有名片信息")

def search_card(card,name):
	flag = 0
	for i in card:
			for j in i:
				if j == name:
					flag = 1
					print("-----------------------")
					print("we find it")
					print("-----------------------")
					tmp = input("do you want to modify the info?")
					if tmp == "yes":
						tmp = deal_card(card,name)
						if tmp == 0:
							return 0
					else:
						return 0
	if flag == 0:
		print("-----------------------")
		print("there's no such a name!")
		print("-----------------------")

def deal_card(card,name):
	print("----------------")
	print("0 返回")
	print("1 修改")
	print("2 删除")
	print("----------------")
	num = int(input("input the number of function to choose:"))
	print("------------------------------------------------")
	if num == 1:
		l = []
		l = input_card_info()
		for i in card:
			for j in i:
				if j == name:
					card[card.index(i)] = l
					print("----------")
					print("修改成功")
					print("----------")
					return 0
	elif num == 2:
		for i in card:
			for j in i:
				if j == name:
					card.remove(i)
					print("----------")
					print("删除成功")
					print("----------")
					return 0
	elif num == 0:
		return 0
