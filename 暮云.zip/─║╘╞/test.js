var fs = require('fs');
var ejs = require('ejs');
var ses = require('express-session');  // 会话session中间件
var exp = require('express');  // express Web中间件
var app = exp();  // 激活express中间件

app.use(exp.static(__dirname + "/public"));  

app.use(ses({  //实例化
	resave : true,
    saveUninitialized: false, // 是否保存未初始化的会话
	name: '0123456789AB',   // 对session id 相关的cookie 进行签名
    secret : '20190519',
    cookie : { maxAge : 20 * 60 * 1000} // 设置 session 有效时间，单位毫秒，超时则会话自动清空
}));

app.get("/", function (req, res){
	fs.readFile("views/index.ejs","utf-8",function(e,data) { /*直接读写文件，与上述的静态路径无关。*/
		var date = new Date();
		console.log("进入登录页面");
		res.write(ejs.render(data, {time: date}));
		res.end();
	});
});

app.get("/check", function (req, res){
	var userNo = req.query.userNo;
	var password = req.query.password;
	var row = checkUser(userNo, password);
	if(row.success == 2) {
		req.session.userNo = userNo; // 登录成功，设置 session
		console.log("进入信息检索页面");
		res.write(JSON.stringify(row));
	}
	else if(row.success == 0 || row.success == 1) {//0:不存在 1：密码错误
		res.write(JSON.stringify(row));
	}
	else{
	 	res.redirect(302,'/');  /*登陆失败，302临时重定向到登录主页 301永久 vs location */
	}
	res.end();
});

app.get("/main", function (req, res){
	//判断session 状态，如果有效，则返回主页，否则转到登录页面
	if(req.session && req.session.userNo) { /* 该会话有效 */
		fs.readFile("views/main.html","utf-8",function(e,data){ /*直接读写文件，与上述的静态路径无关。*/
			res.write(data);
			res.end();
		});
	}
	else{
		res.redirect(302,'/'); 
		res.end();
	}
});


app.get('/search',function(req, res){
	if(req.session && req.session.userNo) {
		var no = req.query.Mno;
		console.log("检索开始")
		res.send(getMData(no));
	}else{
		res.redirect(302,'/'); 
		res.end();
	}
});

app.get('/update',function(req, res){  
	if(req.session && req.session.userNo) {
		var no = req.query.Mno;
		var name = req.query.Mname;
		var age = req.query.Mage;
		var data = req.query.Mdata;
		var datas = fs.readFileSync("views/base.json", "utf-8");
		var Mdatas = JSON.parse(datas.toString());
		var newData = new Array();
		for(i in Mdatas){
			newData[i] = Mdatas[i];  
		}
		newData[Mdatas.length] = {
			"Mno" : no,
			"Mname" : name,
			"Mage" : age,
			"Mdata" : data
		};
		fs.writeFile("views/base.json", JSON.stringify(newData), function(err){
			if(err) res.send("0");
			else res.send("2");
		});
	}else{
		res.redirect(302,'/');  
		res.end();
	}
});

app.get('/delete',function(req, res){ 
	if(req.session && req.session.userNo) {
		console.log("准备删除");
		var no = req.query.Mno;
		var flag = false;
		var data = fs.readFileSync("views/base.json", "utf-8");
		var Mdata = JSON.parse(data.toString());
		var ans = new Array();
		var j = 0;
		for(var i in Mdata){
			if(no == Mdata[i].Mno){
				i++;
				flag = true;
			}else {
				ans[j++] = Mdata[i];
			}
		} 
		fs.writeFile("views/base.json", JSON.stringify(ans),function(err){
			if(!err)flag = true;
		});
		if(flag) {
			console.log("删除成功！");
			res.send("1");
		}else res.send("0");
	}else{
		res.redirect(302,'/'); 
		res.end();
	}
});

function getUsers(){  // 帐号记录
	var data = fs.readFileSync("views/users.json","utf-8");  /*同步方法读写文件，与上述的静态路径无关。*/
	var str = data.toString();	  // 将二进制文件转为字符串，然后转为json
	return JSON.parse(str);   // 数组也算一个json对象	
}

function checkUser(userNo, password){ /* 获取记录并返回是否存在的结果。 */
	var rows = getUsers();
	var row = FindUser(rows, userNo);
	if(!row) return {"success": 0};
	if(row.password != password) return {"success": 1};
	row.success = 2;
	return row;
}

function FindUser(rows, userNo){ /* 查找帐号记录 */
	for(var k = 0; k < rows.length; k++){
		if(rows[k].userNo == userNo) return rows[k];
	}
	return null;
}

function getMData(no){
	var data = fs.readFileSync("views/base.json", "utf-8");
    var Mdata = JSON.parse(data.toString());
    for(var i in Mdata){
		if(no == Mdata[i].Mno){
			console.log("检索成功！");
			Mdata[i].success = 1;
			return JSON.stringify(Mdata[i]);
		}
	} 
	return {"success" : 0};
}

app.listen(50412, function(){
	console.log("网站：http://localhost:50412!");
});